# -*- coding: utf-8 -*-
"""
    xerox.default_config
    ~~~~~~~~~~~~~~~~~~~~

    The default configuration for the xerox application.

    :copyright: (c) 2011 by Armin Ronacher.
    :license: BSD, see LICENSE for more details.
"""
